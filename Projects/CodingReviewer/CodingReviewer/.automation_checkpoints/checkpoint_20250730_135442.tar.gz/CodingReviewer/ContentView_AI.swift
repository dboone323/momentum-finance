//
//  ContentView_AI.swift
//  CodingReviewer
//
//  Phase 4: Enhanced AI Interface with Intelligent Fix Generation
//  Created on July 25, 2025
//

import SwiftUI
import Foundation

// MARK: - AI Insights Tab Enum

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

enum AIInsightsTab: String, CaseIterable {
    case analysis = "Analysis"
    case patterns = "Patterns"
    case fixes = "Fixes"
    case history = "History"

    var systemImage: String {
        switch self {
        case .analysis: return "magnifyingglass.circle"
        case .patterns: return "brain.head.profile"
        case .fixes: return "wrench.and.screwdriver"
        case .history: return "clock.arrow.circlepath"
        }
    }
}

// MARK: - Enhanced AI Insights View

struct AIInsightsView: View {
    @EnvironmentObject var fileManager: FileManagerService
    @StateObject private var fixGenerator = IntelligentFixGenerator()
    @StateObject private var fixHistory = FixHistoryManager()
    @StateObject private var patternEngine = PatternRecognitionEngine()

    @State private var selectedAnalysisRecord: FileAnalysisRecord?
    @State private var showingFixApplication = false
    @State private var showingFixHistory = false
    @State private var showingPatternAnalysis = false
    @State private var currentModifiedCode: String = ""
    @State private var selectedTab: AIInsightsTab = .analysis

    var body: some View {
        VStack(spacing: 0) {
            // AI Header with Status
            AIStatusHeader(
                analysisCount: fileManager.analysisHistory.count,
                fixesAvailable: fixGenerator.generatedFixes.count,
                onShowHistory: { showingFixHistory = true }
            )

            Divider()

            if fileManager.analysisHistory.isEmpty && fileManager.uploadedFiles.isEmpty {
                // Empty State - no files at all
                AIEmptyStateView()
            } else if fileManager.analysisHistory.isEmpty && !fileManager.uploadedFiles.isEmpty {
                // Show uploaded files available for analysis
                AIUploadedFilesView(
                    uploadedFiles: fileManager.uploadedFiles,
                    onAnalyzeFiles: {
                        Task {
                            await analyzeUploadedFiles()
                        }
                    }
                )
            } else {
                HSplitView {
                    // Left Panel: Analysis History
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Analysis History")
                            .font(.headline)
                            .padding()

                        Divider()

                        AnalysisHistoryList(
                            records: fileManager.analysisHistory,
                            selectedRecord: $selectedAnalysisRecord
                        )
                    }
                    .frame(minWidth: 300)

                    // Right Panel: AI Insights & Fix Generation
                    VStack(spacing: 0) {
                        if let record = selectedAnalysisRecord {
                            AIAnalysisDetailView(
                                record: record,
                                onGenerateFixes: { analysisRecord in
                                    currentModifiedCode = analysisRecord.originalCode ?? ""
                                    showingFixApplication = true
                                }
                            )
                        } else {
                            AISelectionPromptView()
                        }
                    }
                    .frame(minWidth: 400)
                }
            }
        }
        .sheet(isPresented: $showingFixApplication) {
            if let record = selectedAnalysisRecord {
                NavigationView {
                    FixApplicationView(
                        analysis: createFallbackResult(from: record),
                        originalCode: record.originalCode ?? "",
                        onFixesApplied: { modifiedCode in
                            currentModifiedCode = modifiedCode
                            showingFixApplication = false

                            // Record in history
                            if let fix = fixGenerator.generatedFixes.first {
                                fixHistory.recordAppliedFix(
                                    fix,
                                    originalCode: record.originalCode ?? "",
                                    modifiedCode: modifiedCode,
                                    fileName: record.fileName
                                )
                            }
                        }
                    )
                    .navigationTitle("Apply Intelligent Fixes")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Close") {
                                showingFixApplication = false
                            }
                        }
                    }
                }
                .frame(minWidth: 800, minHeight: 600)
            }
        }
        .sheet(isPresented: $showingFixHistory) {
            FixHistoryView(historyManager: fixHistory)
        }
    }
    
    @MainActor
    private func analyzeUploadedFiles() async {
        guard !fileManager.uploadedFiles.isEmpty else { return }
        
        do {
            // Use the file manager's analysis method to create analysis history
            _ = try await fileManager.analyzeMultipleFiles(fileManager.uploadedFiles, withAI: true)
        } catch {
            fileManager.errorMessage = "Failed to analyze uploaded files: \(error.localizedDescription)"
        }
    }

    private func createFallbackResult(from record: FileAnalysisRecord) -> EnhancedAnalysisResult {
        EnhancedAnalysisResult(
            fileName: record.fileName,
            fileSize: record.originalCode?.count ?? 0,
            language: record.language ?? "unknown",
            originalResults: record.results.map { $0.message },
            aiSuggestions: [],
            complexity: 50.0,
            maintainability: 75.0,
            fixes: [],
            summary: AnalysisSummary(
                totalSuggestions: 0,
                criticalIssues: 0,
                errors: 0,
                warnings: 0,
                infos: 0,
                complexityScore: 50,
                maintainabilityScore: 75.0
            )
        )
    }

    private func createEnhancedResult(from record: FileAnalysisRecord) -> EnhancedAnalysisResult {
        EnhancedAnalysisResult(
            fileName: record.file.name,
            fileSize: record.file.size,
            language: record.file.language.rawValue,
            originalResults: record.analysisResults.map { $0.message },
            aiSuggestions: record.aiAnalysisResult != nil ? [record.aiAnalysisResult!] : [],
            complexity: 50.0,
            maintainability: 75.0,
            fixes: [],
            summary: AnalysisSummary(
                totalSuggestions: record.analysisResults.count,
                criticalIssues: 0,
                errors: 0,
                warnings: record.analysisResults.count,
                infos: 0,
                complexityScore: 50,
                maintainabilityScore: 75.0
            )
        )
    }
}

// MARK: - AI Status Header

struct AIStatusHeader: View {
    let analysisCount: Int
    let fixesAvailable: Int
    let onShowHistory: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("AI-Powered Code Analysis")
                    .font(.title2)
                    .fontWeight(.semibold)

                Text("\(analysisCount) files analyzed")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()

            HStack(spacing: 16) {
                // Fixes Available Badge
                if fixesAvailable > 0 {
                    HStack(spacing: 4) {
                        Image(systemName: "wrench.and.screwdriver.fill")
                            .foregroundColor(.blue)
                        Text("\(fixesAvailable) fixes available")
                            .font(.caption)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(6)
                }

                // History Button
                Button("Fix History", action: onShowHistory)
                    .buttonStyle(.bordered)
                    .controlSize(.small)
            }
        }
        .padding()
    }
}

// MARK: - Empty State

struct AIEmptyStateView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "brain.head.profile")
                .font(.system(size: 64))
                .foregroundColor(.blue)

            Text("AI Analysis Ready")
                .font(.title)
                .fontWeight(.semibold)

            Text("Upload files and run analysis to see AI-powered insights and intelligent fix suggestions.")
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)

            NavigationLink(destination: FileUploadView()) {
                Label("Upload Files", systemImage: "folder.badge.plus")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Analysis History List

struct AnalysisHistoryList: View {
    let records: [FileAnalysisRecord]
    @Binding var selectedRecord: FileAnalysisRecord?

    var body: some View {
        List(records, id: \.id, selection: $selectedRecord) { record in
            AnalysisRecordRow(record: record)
        }
        .listStyle(SidebarListStyle())
    }
}

struct AnalysisRecordRow: View {
    let record: FileAnalysisRecord

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(record.fileName)
                .font(.headline)
                .lineLimit(1)

            HStack {
                if let language = record.language {
                    Text(language.uppercased())
                        .font(.caption2)
                        .padding(.horizontal, 4)
                        .padding(.vertical, 1)
                        .background(Color.blue.opacity(0.2))
                        .cornerRadius(3)
                }

                Text("\(record.results.count) issues")
                    .font(.caption)
                    .foregroundColor(.secondary)

                Spacer()

                if record.hasAIAnalysis {
                    Image(systemName: "brain.head.profile")
                        .font(.caption)
                        .foregroundColor(.blue)
                }
            }

            Text(formatDate(record.timestamp))
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 2)
    }

    private func formatDate(_ date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}

// MARK: - AI Analysis Detail View

struct AIAnalysisDetailView: View {
    let record: FileAnalysisRecord
    let onGenerateFixes: (FileAnalysisRecord) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(record.fileName)
                        .font(.title2)
                        .fontWeight(.semibold)

                    Spacer()

                    Button("Generate Intelligent Fixes") {
                        onGenerateFixes(record)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(!record.hasAIAnalysis)
                }

                HStack {
                    if let language = record.language {
                        Label(language, systemImage: "doc.text")
                            .font(.caption)
                    }

                    Label("\(record.results.count) issues", systemImage: "exclamationmark.triangle")
                        .font(.caption)

                    if record.hasAIAnalysis {
                        Label("AI Enhanced", systemImage: "brain.head.profile")
                            .font(.caption)
                            .foregroundColor(.blue)
                    }
                }
                .foregroundColor(.secondary)
            }
            .padding()

            Divider()

            // Analysis Results
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 12) {
                    // AI Suggestions Section
                    if let enhancedResult = record.enhancedResult,
                       !enhancedResult.aiSuggestions.isEmpty {

                        AISuggestionsSection(suggestions: enhancedResult.aiSuggestions)
                    }

                    // Code Quality Metrics (temporarily disabled due to type mismatch)
                    // if let enhancedResult = record.enhancedResult {
                    //     CodeQualityMetricsSection(result: enhancedResult)
                    // }

                    // Traditional Analysis Results
                    AnalysisResultsSection(results: record.results)
                }
                .padding()
            }
        }
    }
}

// MARK: - AI Suggestions Section

struct AISuggestionsSection: View {
    let suggestions: [String]

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("AI-Powered Suggestions", systemImage: "brain.head.profile")
                .font(.headline)
                .foregroundColor(.blue)

            ForEach(Array(suggestions.enumerated()), id: \.offset) { _, suggestion in
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "lightbulb.fill")
                        .foregroundColor(.yellow)
                        .frame(width: 20)

                    Text(suggestion)
                        .font(.body)
                        .fixedSize(horizontal: false, vertical: true)

                    Spacer()
                }
                .padding()
                .background(Color.yellow.opacity(0.1))
                .cornerRadius(8)
            }
        }
    }
}

// MARK: - Code Quality Metrics Section

struct CodeQualityMetricsSection: View {
    let result: EnhancedAnalysisResult

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Code Quality Metrics", systemImage: "chart.bar.fill")
                .font(.headline)

            HStack(spacing: 20) {
                MetricCard(
                    title: "Complexity",
                    value: "\(Int(result.complexity ?? 0))",
                    color: complexityColor(result.complexity ?? 0)
                )

                MetricCard(
                    title: "Maintainability",
                    value: "\(Int(result.maintainability ?? 0))%",
                    color: maintainabilityColor(result.maintainability ?? 0)
                )

                MetricCard(
                    title: "Issues",
                    value: "\(result.summary.totalSuggestions)",
                    color: .orange
                )
            }
        }
    }

    private func complexityColor(_ complexity: Double) -> Color {
        if complexity < 30 { return .green }
        if complexity < 60 { return .yellow }
        return .red
    }

    private func maintainabilityColor(_ maintainability: Double) -> Color {
        if maintainability > 80 { return .green }
        if maintainability > 60 { return .yellow }
        return .red
    }
}

struct MetricCard: View {
    let title: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(color)

            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(color.opacity(0.1))
        .cornerRadius(8)
    }
}

// MARK: - Analysis Results Section

struct AnalysisResultsSection: View {
    let results: [AnalysisResult]

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Analysis Results", systemImage: "list.bullet")
                .font(.headline)

            ForEach(0..<results.count, id: \.self) { index in
                AnalysisResultCard(result: results[index])
            }
        }
    }
}

struct AnalysisResultCard: View {
    let result: AnalysisResult

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: result.severity.systemImage)
                .foregroundColor(result.severity.color)
                .frame(width: 20)

            VStack(alignment: .leading, spacing: 4) {
                Text(result.message)
                    .font(.body)
                    .fixedSize(horizontal: false, vertical: true)

                if let line = result.line {
                    Text("Line \(line)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }

            Spacer()
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(8)
    }
}

// MARK: - Selection Prompt

struct AISelectionPromptView: View {
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "arrow.left")
                .font(.system(size: 32))
                .foregroundColor(.secondary)

            Text("Select Analysis")
                .font(.title2)
                .fontWeight(.semibold)

            Text("Choose an analysis from the left panel to view AI insights and generate intelligent fixes.")
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

// MARK: - Fix History View

struct FixHistoryView: View {
    @ObservedObject var historyManager: FixHistoryManager
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            VStack {
                if historyManager.history.isEmpty {
                    VStack(spacing: 16) {
                        Image(systemName: "clock")
                            .font(.system(size: 48))
                            .foregroundColor(.secondary)

                        Text("No Fix History")
                            .font(.title2)
                            .fontWeight(.semibold)

                        Text("Applied fixes will appear here for reference.")
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(historyManager.history) { entry in
                        FixHistoryEntryView(entry: entry)
                    }
                }
            }
            .navigationTitle("Fix History")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") {
                        dismiss()
                    }
                }
            }
        }
        .frame(minWidth: 600, minHeight: 400)
    }
}

struct FixHistoryEntryView: View {
    let entry: FixHistoryEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(entry.fileName)
                    .font(.headline)

                Spacer()

                Text(entry.formattedDate)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Text("Fix applied successfully")
                .font(.body)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Extensions

extension AnalysisResult.Severity {
    var systemImage: String {
        switch self {
        case .low: return "info.circle"
        case .medium: return "exclamationmark.triangle"
        case .high: return "exclamationmark.triangle.fill"
        case .critical: return "xmark.octagon.fill"
        }
    }

    var color: Color {
        switch self {
        case .low: return .blue
        case .medium: return .yellow
        case .high: return .orange
        case .critical: return .red
        }
    }
}

// MARK: - AI Uploaded Files View

struct AIUploadedFilesView: View {
    let uploadedFiles: [CodeFile]
    let onAnalyzeFiles: () -> Void
    
    var body: some View {
        VStack(spacing: 24) {
            // Header
            VStack(spacing: 12) {
                Image(systemName: "brain.head.profile")
                    .font(.system(size: 48))
                    .foregroundColor(.blue)
                
                Text("Files Ready for AI Analysis")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Upload complete! Your files are ready to be analyzed by our AI systems.")
                    .font(.body)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            
            // Files overview
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text("Uploaded Files")
                        .font(.headline)
                    
                    Spacer()
                    
                    Text("\(uploadedFiles.count) files")
                        .font(.subheadline)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(8)
                }
                
                // Language breakdown
                let languageGroups = Dictionary(grouping: uploadedFiles, by: { $0.language })
                let sortedLanguages = Array(Set(uploadedFiles.map { $0.language })).sorted(by: { $0.displayName < $1.displayName })
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 12) {
                    ForEach(sortedLanguages, id: \.self) { language in
                        HStack(spacing: 8) {
                            Image(systemName: language.iconName)
                                .foregroundColor(.blue)
                            
                            VStack(alignment: .leading, spacing: 2) {
                                Text(language.displayName)
                                    .font(.subheadline)
                                    .fontWeight(.medium)
                                
                                Text("\(languageGroups[language]?.count ?? 0) files")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(Color(.controlBackgroundColor))
                        .cornerRadius(8)
                    }
                }
                
                // Recent files preview
                if !uploadedFiles.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Recent Files")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        
                        ForEach(Array(uploadedFiles.prefix(5)), id: \.id) { file in
                            HStack(spacing: 12) {
                                Image(systemName: file.language.iconName)
                                    .foregroundColor(.blue)
                                    .frame(width: 20)
                                
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(file.name)
                                        .font(.body)
                                        .lineLimit(1)
                                    
                                    Text("\(file.displaySize) • \(file.language.displayName)")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                
                                Spacer()
                            }
                            .padding(.vertical, 4)
                        }
                        
                        if uploadedFiles.count > 5 {
                            Text("... and \(uploadedFiles.count - 5) more files")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .padding(.top, 4)
                        }
                    }
                    .padding()
                    .background(Color(.controlBackgroundColor).opacity(0.5))
                    .cornerRadius(8)
                }
            }
            .frame(maxWidth: 500)
            
            // Action button
            Button("Start AI Analysis") {
                onAnalyzeFiles()
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}
