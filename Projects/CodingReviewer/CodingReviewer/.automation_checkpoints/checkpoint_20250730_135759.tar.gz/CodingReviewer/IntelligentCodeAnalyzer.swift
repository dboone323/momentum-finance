// SECURITY: API key handling - ensure proper encryption and keychain storage
import Foundation
import OSLog

// MARK: - Intelligent Code Issue Analyzer
// TODO: Review error handling in this file - Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

// TODO: Review error handling in this file
// Consider wrapping force unwraps and try statements in proper error handling

class IntelligentCodeAnalyzer {
    static let shared = IntelligentCodeAnalyzer()
    private let logger = OSLog(subsystem: "CodingReviewer", category: "CodeAnalyzer")
    
    private init() {}
    
    // MARK: - Main Analysis Methods
    
    func analyzeProject(at projectPath: String) async throws -> String {
        os_log("Starting intelligent code analysis for project at %@", log: logger, type: .info, projectPath)
        
        let startTime = Date()
        let swiftFiles = try findSwiftFiles(in: projectPath)
        var totalIssues = 0
        
        for filePath in swiftFiles {
            let fileIssues = try await analyzeFile(at: filePath)
            totalIssues += fileIssues.count
        }
        
        let duration = Date().timeIntervalSince(startTime)
        let result = "Analyzed \(swiftFiles.count) files, found \(totalIssues) issues in \(String(format: "%.2f", duration)) seconds"
        
        os_log("Analysis complete: %@", log: logger, type: .info, result)
        return result
    }
    
    func analyzeFile(at filePath: String) async throws -> [CodeIssue] {
        guard FileManager.default.fileExists(atPath: filePath) else {
            throw AnalyzerError.fileNotFound(filePath)
        }
        
        let content = try String(contentsOfFile: filePath, encoding: .utf8)
        let lines = content.components(separatedBy: .newlines)
        
        var issues: [CodeIssue] = []
        
        // Run various analysis passes
        issues.append(contentsOf: analyzeSwiftConcurrency(lines: lines, filePath: filePath))
        issues.append(contentsOf: analyzeCodeQuality(lines: lines, filePath: filePath))
        issues.append(contentsOf: analyzePerformance(lines: lines, filePath: filePath))
        issues.append(contentsOf: analyzeSecurity(lines: lines, filePath: filePath))
        issues.append(contentsOf: analyzeSwiftBestPractices(lines: lines, filePath: filePath))
        issues.append(contentsOf: analyzeArchitecturalPatterns(lines: lines, filePath: filePath))
        
        return issues
    }
    
    // MARK: - Specific Analysis Methods
    
    private func analyzeSwiftConcurrency(lines: [String], filePath: String) -> [CodeIssue] {
        var issues: [CodeIssue] = []
        
        for (index, line) in lines.enumerated() {
            let lineNumber = index + 1
            
            // Check for main actor isolation issues
            if line.contains(".shared.") && !line.contains("await") && 
               (line.contains("AppLogger") || line.contains("PerformanceTracker")) {
                issues.append(CodeIssue(
                    type: .concurrencyIssue,
                    severity: .warning,
                    filePath: filePath,
                    lineNumber: lineNumber,
                    message: "Main actor-isolated property access should use await",
                    originalCode: line.trimmingCharacters(in: .whitespaces),
                    suggestedFix: line.replacingOccurrences(of: ".shared.", with: "await .shared."),
                    isAutoFixable: true,
                    category: .concurrency
                ))
            }
            
            // Check for missing @MainActor annotations
            if line.contains("class") && line.contains("ObservableObject") && !line.contains("@MainActor") {
                issues.append(CodeIssue(
                    type: .missingMainActor,
                    severity: .warning,
                    filePath: filePath,
                    lineNumber: lineNumber,
                    message: "ObservableObject classes should be marked with @MainActor",
                    originalCode: line.trimmingCharacters(in: .whitespaces),
                    suggestedFix: "@MainActor\n" + line,
                    isAutoFixable: true,
                    category: .concurrency
                ))
            }
        }
        
        return issues
    }
    
    private func analyzeCodeQuality(lines: [String], filePath: String) -> [CodeIssue] {
        var issues: [CodeIssue] = []
        
        for (index, line) in lines.enumerated() {
            let lineNumber = index + 1
            let trimmedLine = line.trimmingCharacters(in: .whitespaces)
            
            // Check for unused variables (let _ pattern)
            if let range = trimmedLine.range(of: #"let\s+([a-zA-Z_]\w*)\s*="#, options: .regularExpression) {
                let variableName = String(trimmedLine[range]).replacingOccurrences(of: "let ", with: "").replacingOccurrences(of: " =", with: "")
                
                // Check if variable is used in subsequent lines (simple heuristic)
                let remainingLines = Array(lines[(index + 1)...])
                let isUsed = remainingLines.joined().contains(variableName)
                
                if !isUsed {
                    issues.append(CodeIssue(
                        type: .unusedVariable,
                        severity: .warning,
                        filePath: filePath,
                        lineNumber: lineNumber,
                        message: "Variable '\(variableName)' is never used",
                        originalCode: trimmedLine,
                        suggestedFix: trimmedLine.replacingOccurrences(of: "let \(variableName)", with: "let _"),
                        isAutoFixable: true,
                        category: .codeQuality
                    ))
                }
            }
            
            // Check for var that should be let
            if trimmedLine.contains("var ") && !trimmedLine.contains("=") {
                // Simple heuristic: if var is declared but never reassigned
                issues.append(CodeIssue(
                    type: .mutableToImmutable,
                    severity: .info,
                    filePath: filePath,
                    lineNumber: lineNumber,
                    message: "Consider using 'let' instead of 'var' if value doesn't change",
                    originalCode: trimmedLine,
                    suggestedFix: trimmedLine.replacingOccurrences(of: "var ", with: "let "),
                    isAutoFixable: false, // Requires semantic analysis
                    category: .codeQuality
                ))
            }
            
            // Check for long lines
            if line.count > 120 {
                issues.append(CodeIssue(
                    type: .longLine,
                    severity: .info,
                    filePath: filePath,
                    lineNumber: lineNumber,
                    message: "Line exceeds 120 characters (\(line.count) chars)",
                    originalCode: String(line.prefix(50)) + "...",
                    suggestedFix: "Consider breaking this line into multiple lines",
                    isAutoFixable: false,
                    category: .formatting
                ))
            }
        }
        
        return issues
    }
    
    private func analyzePerformance(lines: [String], filePath: String) -> [CodeIssue] {
        var issues: [CodeIssue] = []
        
        for (index, line) in lines.enumerated() {
            let lineNumber = index + 1
            
            // Check for string concatenation in loops
            if line.contains("for ") && lines.dropFirst(index).prefix(10).contains(where: { $0.contains("+") && $0.contains("\"") }) {
                issues.append(CodeIssue(
                    type: .inefficientStringConcatenation,
                    severity: .warning,
                    filePath: filePath,
                    lineNumber: lineNumber,
                    message: "String concatenation in loop can be inefficient",
                    originalCode: line.trimmingCharacters(in: .whitespaces),
                    suggestedFix: "Consider using StringBuilder or array.joined()",
                    isAutoFixable: false,
                    category: .performance
                ))
            }
            
            // Check for force unwrapping
            if line.contains("!") && !line.contains("//") && !line.contains("\"") {
                let forceUnwrapPattern = #"[a-zA-Z_]\w*!"#
                if line.range(of: forceUnwrapPattern, options: .regularExpression) != nil {
                    issues.append(CodeIssue(
                        type: .forceUnwrapping,
                        severity: .warning,
                        filePath: filePath,
                        lineNumber: lineNumber,
                        message: "Force unwrapping can cause crashes",
                        originalCode: line.trimmingCharacters(in: .whitespaces),
                        suggestedFix: "Use optional binding or nil coalescing operator",
                        isAutoFixable: false, // Requires context
                        category: .safety
                    ))
                }
            }
        }
        
        return issues
    }
    
    private func analyzeSecurity(lines: [String], filePath: String) -> [CodeIssue] {
        var issues: [CodeIssue] = []
        
        for (index, line) in lines.enumerated() {
            let lineNumber = index + 1
            
            // Check for print statements (should use logging)
            if line.contains("await AppLogger.shared.log(") && !line.contains("//") {
                issues.append(CodeIssue(
                    type: .insecureLogging,
                    severity: .warning,
                    filePath: filePath,
                    lineNumber: lineNumber,
                    message: "Use secure logging instead of print statements",
                    originalCode: line.trimmingCharacters(in: .whitespaces),
                    suggestedFix: line.replacingOccurrences(of: "await AppLogger.shared.log(", with: "os_log("),
                    isAutoFixable: true,
                    category: .security
                ))
            }
            
            // Check for hardcoded API keys or secrets
            let secretPatterns = ["apikey", "secret", "password", "token"]
            for pattern in secretPatterns {
                if line.lowercased().contains(pattern) && line.contains("=") && line.contains("\"") {
                    issues.append(CodeIssue(
                        type: .hardcodedSecret,
                        severity: .error,
                        filePath: filePath,
                        lineNumber: lineNumber,
                        message: "Potential hardcoded secret detected",
                        originalCode: "*** REDACTED ***",
                        suggestedFix: "Move sensitive data to secure storage (Keychain)",
                        isAutoFixable: false,
                        category: .security
                    ))
                }
            }
        }
        
        return issues
    }
    
    private func analyzeSwiftBestPractices(lines: [String], filePath: String) -> [CodeIssue] {
        var issues: [CodeIssue] = []
        
        for (index, line) in lines.enumerated() {
            let lineNumber = index + 1
            
            // Check for magic numbers
            let magicNumberPattern = #"\b([2-9]|[1-9][0-9]+)\b"#
            if line.range(of: magicNumberPattern, options: .regularExpression) != nil && 
               !line.contains("//") && !line.contains("case") && !line.contains("version") {
                issues.append(CodeIssue(
                    type: .magicNumber,
                    severity: .info,
                    filePath: filePath,
                    lineNumber: lineNumber,
                    message: "Consider extracting magic numbers to named constants",
                    originalCode: line.trimmingCharacters(in: .whitespaces),
                    suggestedFix: "Extract to a named constant",
                    isAutoFixable: false,
                    category: .maintainability
                ))
            }
            
            // Check for missing access control
            if (line.contains("class ") || line.contains("struct ") || line.contains("enum ")) && 
               !line.contains("private") && !line.contains("public") && !line.contains("internal") {
                issues.append(CodeIssue(
                    type: .missingAccessControl,
                    severity: .info,
                    filePath: filePath,
                    lineNumber: lineNumber,
                    message: "Consider adding explicit access control",
                    originalCode: line.trimmingCharacters(in: .whitespaces),
                    suggestedFix: "Add appropriate access modifier (private, internal, public)",
                    isAutoFixable: false,
                    category: .codeQuality
                ))
            }
        }
        
        return issues
    }
    
    private func analyzeArchitecturalPatterns(lines: [String], filePath: String) -> [CodeIssue] {
        var issues: [CodeIssue] = []
        
        // Check for large functions (simple heuristic)
        var currentFunctionStart: Int?
        var braceCount = 0
        
        for (index, line) in lines.enumerated() {
            let lineNumber = index + 1
            
            // Detect function start
            if line.contains("func ") && line.contains("{") {
                currentFunctionStart = lineNumber
                braceCount = 1
            } else if let _ = currentFunctionStart {
                braceCount += line.filter { $0 == "{" }.count
                braceCount -= line.filter { $0 == "}" }.count
                
                if braceCount == 0 {
                    // Function ended
                    let functionLength = lineNumber - (currentFunctionStart ?? 0)
                    if functionLength > 30 {
                        issues.append(CodeIssue(
                            type: .longFunction,
                            severity: .warning,
                            filePath: filePath,
                            lineNumber: currentFunctionStart ?? lineNumber,
                            message: "Function is \(functionLength) lines long, consider refactoring",
                            originalCode: "Function at line \(currentFunctionStart ?? 0)",
                            suggestedFix: "Break into smaller, focused functions",
                            isAutoFixable: false,
                            category: .maintainability
                        ))
                    }
                    currentFunctionStart = nil
                }
            }
        }
        
        return issues
    }
    
    // MARK: - Helper Methods
    
    private func findSwiftFiles(in directory: String) throws -> [String] {
        let fileManager = FileManager.default
        let enumerator = fileManager.enumerator(atPath: directory)
        var swiftFiles: [String] = []
        
        while let file = enumerator?.nextObject() as? String {
            if file.hasSuffix(".swift") && !file.contains("/.build/") && !file.contains("/DerivedData/") {
                swiftFiles.append((directory as NSString).appendingPathComponent(file))
            }
        }
        
        return swiftFiles
    }
    
    private func generateRecommendations(from issues: [CodeIssue]) -> [Recommendation] {
        var recommendations: [Recommendation] = []
        
        let issuesByCategory = Dictionary(grouping: issues) { $0.category }
        
        for (category, categoryIssues) in issuesByCategory {
            let count = categoryIssues.count
            let autoFixable = categoryIssues.filter { $0.isAutoFixable }.count
            
            recommendations.append(Recommendation(
                category: category,
                priority: count > 10 ? .high : count > 5 ? .medium : .low,
                description: "\(count) \(category.rawValue) issues found (\(autoFixable) auto-fixable)",
                action: autoFixable > 0 ? "Run automatic fixes" : "Manual review required"
            ))
        }
        
        return recommendations.sorted { $0.priority.rawValue > $1.priority.rawValue }
    }
}

// MARK: - Supporting Types

struct CodeIssue {
    let type: IssueType
    let severity: Severity
    let filePath: String
    let lineNumber: Int
    let message: String
    let originalCode: String
    let suggestedFix: String
    let isAutoFixable: Bool
    let category: Category
    
    enum IssueType {
        case concurrencyIssue
        case missingMainActor
        case unusedVariable
        case mutableToImmutable
        case longLine
        case inefficientStringConcatenation
        case forceUnwrapping
        case insecureLogging
        case hardcodedSecret
        case magicNumber
        case missingAccessControl
        case longFunction
    }
    
    enum Severity: Int {
        case error = 3
        case warning = 2
        case info = 1
    }
    
    enum Category: String {
        case concurrency = "Concurrency"
        case codeQuality = "Code Quality"
        case formatting = "Formatting"
        case performance = "Performance"
        case safety = "Safety"
        case security = "Security"
        case maintainability = "Maintainability"
    }
}

struct Recommendation {
    let category: CodeIssue.Category
    let priority: Priority
    let description: String
    let action: String
    
    enum Priority: Int {
        case high = 3
        case medium = 2
        case low = 1
    }
}

enum AnalyzerError: LocalizedError {
    case fileNotFound(String)
    case analysisTimeout
    case invalidSwiftFile(String)
    
    var errorDescription: String? {
        switch self {
        case .fileNotFound(let path):
            return "File not found: \(path)"
        case .analysisTimeout:
            return "Analysis timed out"
        case .invalidSwiftFile(let path):
            return "Invalid Swift file: \(path)"
        }
    }
}
